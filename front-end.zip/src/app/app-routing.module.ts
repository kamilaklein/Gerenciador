import { RelatorioComponent } from './options/relatorio/relatorio.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AtividadesLabComponent } from './options/atividades-lab/atividades-lab.component';
import { ComponentesComponent } from './options/componentes/componentes.component';
import { InfoDashComponent } from './options/dashboard/info-dash/info-dash.component';
import { RegisterUserComponent } from './registrar-usuario/register-user/register-user.component';

const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'dashboard', component: InfoDashComponent},
  {path: 'registrar-usuario', component: RegisterUserComponent},
  {path: 'atividade-lab', component: AtividadesLabComponent},
  {path: 'componentes', component: ComponentesComponent},
  {path: 'relatorios', component: RelatorioComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
