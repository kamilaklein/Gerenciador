import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Atividade } from '../models/atividade.model';

@Injectable({
  providedIn: 'root'
})
export class AtividadeService {
  private apiUrl = 'http://localhost:8080/atividadeslab/list';

  constructor(private http: HttpClient) { }

  listarAtividades(): Observable<Atividade[]> {
    return this.http.get<Atividade[]>(this.apiUrl);
}

obterDados(): Observable<any> {
  return this.http.get<any>('/src/assets/dados.json');
}
}
