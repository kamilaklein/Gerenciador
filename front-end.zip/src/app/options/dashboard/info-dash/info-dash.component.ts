import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-dash',
  templateUrl: './info-dash.component.html',
  styleUrls: ['./info-dash.component.css']
})
export class InfoDashComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }


}
