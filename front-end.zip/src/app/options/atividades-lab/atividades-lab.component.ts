import { Component, ViewChild, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { AtividadeService } from 'src/app/service/atividade.service';
import { Atividade } from 'src/app/models/atividade.model';

@Component({
  selector: 'app-atividades-lab',
  templateUrl: './atividades-lab.component.html',
  styleUrls: ['./atividades-lab.component.css']
})
export class AtividadesLabComponent implements OnInit {
  dataSource: MatTableDataSource<Atividade>;
  displayedColumns: string[] = ['id', 'titulo', 'descricao', 'status', 'tempo', 'dataCriacao'];

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;

  constructor(private atividadeService: AtividadeService) {
    this.dataSource = new MatTableDataSource<Atividade>();
  }

  ngOnInit() {
    this.atividadeService.listarAtividades().subscribe((atividades: Atividade[]) => {
      this.dataSource.data = atividades;
      this.dataSource.paginator = this.paginator;
    });
  }
}
