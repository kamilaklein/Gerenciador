import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AtividadesLabComponent } from './atividades-lab.component';

describe('AtividadesLabComponent', () => {
  let component: AtividadesLabComponent;
  let fixture: ComponentFixture<AtividadesLabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AtividadesLabComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AtividadesLabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
