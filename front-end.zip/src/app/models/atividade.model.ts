export interface Atividade {
  id: number;
  titulo: string;
  descricao: string | null;
  status: string;
  tempo: string;
  dataCriacao: string;
}
