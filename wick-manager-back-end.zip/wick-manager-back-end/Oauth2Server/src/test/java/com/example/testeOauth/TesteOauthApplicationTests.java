package com.example.testeOauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
