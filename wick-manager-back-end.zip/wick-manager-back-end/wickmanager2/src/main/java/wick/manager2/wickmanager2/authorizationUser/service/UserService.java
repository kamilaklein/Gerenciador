package wick.manager2.wickmanager2.authorizationUser.service;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

import lombok.var;
import wick.manager2.wickmanager2.authorizationUser.controller.dto.IncludeRequest;
import wick.manager2.wickmanager2.authorizationUser.controller.dto.ToUpdateRequest;
import wick.manager2.wickmanager2.authorizationUser.model.Users;
import wick.manager2.wickmanager2.authorizationUser.repositories.UserRepositories;

@Service
public class UserService {

    private final UserRepositories userRepository;
  
    public UserService(UserRepositories userRepository) {
        this.userRepository= userRepository;
    } 

    public List<Users> list() {
        return userRepository.findAll();
    }

    
    public Users include(IncludeRequest includeRequest) {
        var date = Instant.now();
        var user = new Users();
        BeanUtils.copyProperties(includeRequest, user);
        user.setCreationDate(date);
        user.setLastChanceDate(date);
        userRepository.save(user);
        return user;
    }

    public Users getUserByEmailAndPassword(String emailAddress, String password) {
        return userRepository.findByEmailAddressAndPassword(emailAddress, password);
    }
    

    /*
     * criptografia dos dados
     * public void cadastrarUsuario(User user) {
     * String senha = user.getPassword();
     * String senhaSegura = senha + SALT;
     * 
     * // Calcular o hash MD5 da senha
     * String senhaCriptografada = calcularHashMD5(senhaSegura);
     * 
     * user.setPassword(senhaCriptografada);
     * 
     * // Salvar o usuário no banco de dados
     * userRepository.save(user);
     * }
     * 
     * private String calcularHashMD5(String senha) {
     * try {
     * MessageDigest md = MessageDigest.getInstance("MD5");
     * byte[] digest = md.digest(senha.getBytes());
     * 
     * // Converter o digest para uma representação em hexadecimal
     * StringBuilder sb = new StringBuilder();
     * for (byte b : digest) {
     * sb.append(String.format("%02x", b));
     * }
     * 
     * return sb.toString();
     * } catch (NoSuchAlgorithmException e) {
     * // Lidar com a exceção, se necessário
     * return null;
     * }
     * }
     * 
     * // consulta
     * public User getUserByUsernameAndPassword(String username, String password) {
     * // Obter o usuário pelo nome de usuário
     * User user = userRepository.findByUsername(username);
     * 
     * // Verificar se o usuário existe e se a senha corresponde
     * if (user != null && verificarSenha(password, user.getPassword())) {
     * return user;
     * }
     * 
     * return null;
     * }
     * 
     * private boolean verificarSenha(String senha, String senhaCriptografada) {
     * 
     * String senhaCriptografadaFornecida = calcularHashMD5(senha + SALT);
     * 
     * // Comparar os hashes das senhas
     * return senhaCriptografadaFornecida != null &&
     * senhaCriptografadaFornecida.equals(senhaCriptografada);
     * }
     */

}
