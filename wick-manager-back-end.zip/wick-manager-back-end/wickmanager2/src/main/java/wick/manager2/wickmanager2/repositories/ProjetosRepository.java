package wick.manager2.wickmanager2.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import wick.manager2.wickmanager2.model.Projetos;

@Repository
public interface ProjetosRepository extends JpaRepository<Projetos, Long> {
}