package wick.manager2.wickmanager2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import wick.manager2.wickmanager2.model.Componentes;
import wick.manager2.wickmanager2.repositories.ComponentesRepository;

import java.util.List;

@Service
public class ComponentesService {
    private final ComponentesRepository componentesRepository;

    @Autowired
    public ComponentesService(ComponentesRepository componentesRepository) {
        this.componentesRepository = componentesRepository;
    }

    public List<Componentes> getAllComponentes() {
        return componentesRepository.findAll();
    }

    public Componentes getComponentesById(Long id) {
        return componentesRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException());
    }

    public Componentes createComponentes(Componentes componentes) {
        return componentesRepository.save(componentes);
    }

    public Componentes updateComponentes(Long id, Componentes componentesDetails) {
        Componentes componentes = componentesRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException());

        componentes.setNome(componentesDetails.getNome());
        componentes.setQuantidade(componentesDetails.getQuantidade());
        componentes.setCategoria(componentesDetails.getCategoria());
        componentes.setDescricao(componentesDetails.getDescricao());
        componentes.setDicaDeUso(componentesDetails.getDicaDeUso());
        componentes.setStatus(componentesDetails.getStatus());

        return componentesRepository.save(componentes);
    }

    public void deleteComponentes(Long id) {
        Componentes componentes = componentesRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Componentes"));

        componentesRepository.delete(componentes);
    }
}
