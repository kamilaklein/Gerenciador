package wick.manager2.wickmanager2.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import wick.manager2.wickmanager2.model.AtividadeLab;

public interface AtividadeLabRepository extends JpaRepository<AtividadeLab, Long> {
    // Métodos personalizados de consulta, se necessário
}