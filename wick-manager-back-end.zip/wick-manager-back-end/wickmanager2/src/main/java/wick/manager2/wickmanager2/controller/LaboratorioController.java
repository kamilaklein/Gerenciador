package wick.manager2.wickmanager2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import wick.manager2.wickmanager2.model.Laboratorio;
import wick.manager2.wickmanager2.service.LaboratorioService;

import java.util.List;

@RestController
@RequestMapping("/laboratorios")
public class LaboratorioController {
    private final LaboratorioService laboratorioService;

    @Autowired
    public LaboratorioController(LaboratorioService laboratorioService) {
        this.laboratorioService = laboratorioService;
    }

    @GetMapping
    public ResponseEntity<List<Laboratorio>> getAllLaboratorios() {
        List<Laboratorio> laboratorioList = laboratorioService.getAllLaboratorios();
        return new ResponseEntity<>(laboratorioList, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Laboratorio> getLaboratorioById(@PathVariable("id") Long id) {
        Laboratorio laboratorio = laboratorioService.getLaboratorioById(id);
        return new ResponseEntity<>(laboratorio, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Laboratorio> createLaboratorio(@RequestBody Laboratorio laboratorio) {
        Laboratorio createdLaboratorio = laboratorioService.createLaboratorio(laboratorio);
        return new ResponseEntity<>(createdLaboratorio, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Laboratorio> updateLaboratorio(
            @PathVariable("id") Long id, @RequestBody Laboratorio laboratorio) {
        Laboratorio updatedLaboratorio = laboratorioService.updateLaboratorio(id, laboratorio);
        return new ResponseEntity<>(updatedLaboratorio, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLaboratorio(@PathVariable("id") Long id) {
        laboratorioService.deleteLaboratorio(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}