package wick.manager2.wickmanager2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import wick.manager2.wickmanager2.model.Projetos;
import wick.manager2.wickmanager2.repositories.ProjetosRepository;

import java.util.List;

@Service
public class ProjetosService {
    private final ProjetosRepository projetosRepository;

    @Autowired
    public ProjetosService(ProjetosRepository projetosRepository) {
        this.projetosRepository = projetosRepository;
    }

    public List<Projetos> getAllProjetos() {
        return projetosRepository.findAll();
    }

    public Projetos getProjetosById(Long id) {
        return projetosRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Projetos"));
    }

    public Projetos createProjetos(Projetos projetos) {
        return projetosRepository.save(projetos);
    }

    public Projetos updateProjetos(Long id, Projetos projetosDetails) {
        Projetos projetos = projetosRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Projetos"));

        projetos.setNome(projetosDetails.getNome());

        return projetosRepository.save(projetos);
    }

    public void deleteProjetos(Long id) {
        Projetos projetos = projetosRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Projetos"));

        projetosRepository.delete(projetos);
    }
}