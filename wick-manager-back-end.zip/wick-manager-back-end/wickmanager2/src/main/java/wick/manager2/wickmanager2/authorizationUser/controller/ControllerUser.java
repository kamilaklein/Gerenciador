package wick.manager2.wickmanager2.authorizationUser.controller;

import wick.manager2.wickmanager2.authorizationUser.controller.dto.IncludeRequest;
import wick.manager2.wickmanager2.authorizationUser.controller.dto.IncludeResponse;
import wick.manager2.wickmanager2.authorizationUser.model.Users;
import wick.manager2.wickmanager2.authorizationUser.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.databind.ObjectMapper;


@CrossOrigin
@RestController
@RequestMapping("users")
public class ControllerUser {

    private final UserService userService;
    private final ObjectMapper mapper = new ObjectMapper();

    public ControllerUser(UserService userServicep) {
        this.userService = userServicep;
    }
    @PostMapping()
    public ResponseEntity<IncludeResponse> include(@RequestParam String userData,
            @RequestParam("termoFile") final MultipartFile termoFile,
            @RequestParam("fotoPerfil") MultipartFile fotoPerfil)
            throws IOException {

        final var includeRequest = mapper.readValue(userData,
                IncludeRequest.class);

                includeRequest.setFotoPerfil(termoFile.getInputStream().readAllBytes());
                includeRequest.setTermoFile(fotoPerfil.getInputStream().readAllBytes());

        var user = userService.include(includeRequest);

        var userResponse = new IncludeResponse();
        BeanUtils.copyProperties(user, userResponse);
        return new ResponseEntity<>(userResponse, HttpStatus.CREATED);
    }

    @GetMapping("/login")
    public ResponseEntity<IncludeResponse> login(@RequestParam String emailAddress, @RequestParam String password) {
        Users user = userService.getUserByEmailAndPassword(emailAddress, password);
        if (user == null) {
            // User not found or password incorrect
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        var userResponse = new IncludeResponse();
        BeanUtils.copyProperties(user, userResponse);
        return new ResponseEntity<>(userResponse, HttpStatus.OK);
    }

     /*
     * Criptografia de dados
     * 
     * @GetMapping("/user")
     * public ResponseEntity<User> getUserByUsernameAndPassword(
     * 
     * @RequestParam String username,
     * 
     * @RequestParam String password
     * ) {
     * User user = userService.getUserByUsernameAndPassword(username, password);
     * if (user != null) {
     * return ResponseEntity.ok(user);
     * } else {
     * return ResponseEntity.notFound().build();
     * }
     * 
     * @PostMapping("/register")
     * public ResponseEntity<Void> cadastrarUsuario(@RequestBody User user) {
     * // Verificar se o usuário já existe no banco de dados
     * if (userService.getUserByUsername(user.getUsername()) != null) {
     * return ResponseEntity.badRequest().build();
     * }
     * // Chamar o método para cadastrar o usuário
     * userService.cadastrarUsuario(user);
     * 
     * return ResponseEntity.ok().build();
     * }
     * 
     * @GetMapping("/user")
     * public ResponseEntity<User> getUserByUsernameAndPassword(
     * 
     * @RequestParam String username,
     * 
     * @RequestParam String password
     * ) {
     * User user = userService.getUserByUsernameAndPassword(username, password);
     * if (user != null) {
     * return ResponseEntity.ok(user);
     * } else {
     * return ResponseEntity.notFound().build();
     * }
     * }
     * 
     */

}
