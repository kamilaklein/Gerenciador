package wick.manager2.wickmanager2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import wick.manager2.wickmanager2.model.AtividadeLab;
import wick.manager2.wickmanager2.service.AtividadeLabService;

@CrossOrigin
@RestController
@RequestMapping("/atividadeslab")
public class AtividadeLabController {

    private final AtividadeLabService atividadeLabService;

    @Autowired
    public AtividadeLabController(AtividadeLabService atividadeLabService) {
        this.atividadeLabService = atividadeLabService;
    }

    @GetMapping("/list")
    public ResponseEntity<?> listarAtividadesLab() {
        return ResponseEntity.ok(atividadeLabService.listarAtividadesLab());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarAtividadeLabPorId(@PathVariable Long id) {
        AtividadeLab atividadeLab = atividadeLabService.buscarAtividadeLabPorId(id);
        if (atividadeLab != null) {
            return ResponseEntity.ok(atividadeLab);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("AtividadeLab não encontrada");
        }
    }

    @PostMapping
    public ResponseEntity<?> salvarAtividadeLab(@RequestBody AtividadeLab atividadeLab) {
        return ResponseEntity.status(HttpStatus.CREATED).body(atividadeLabService.salvarAtividadeLab(atividadeLab));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletarAtividadeLab(@PathVariable Long id) {
        atividadeLabService.deletarAtividadeLab(id);
        return ResponseEntity.ok("AtividadeLab deletada com sucesso");
    }

    // Outros métodos do controlador, se necessário

}