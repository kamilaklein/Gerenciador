package wick.manager2.wickmanager2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Wickmanager2Application {

	public static void main(String[] args) {
		SpringApplication.run(Wickmanager2Application.class, args);
	}

}
