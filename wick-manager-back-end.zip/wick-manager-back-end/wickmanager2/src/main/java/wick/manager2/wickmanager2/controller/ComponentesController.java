package wick.manager2.wickmanager2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import wick.manager2.wickmanager2.model.Componentes;
import wick.manager2.wickmanager2.service.ComponentesService;

import java.util.List;

@RestController
@RequestMapping("/componentes")
public class ComponentesController {
    private final ComponentesService componentesService;

    @Autowired
    public ComponentesController(ComponentesService componentesService) {
        this.componentesService = componentesService;
    }

    @GetMapping
    public ResponseEntity<List<Componentes>> getAllComponentes() {
        List<Componentes> componentesList = componentesService.getAllComponentes();
        return new ResponseEntity<>(componentesList, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Componentes> getComponentesById(@PathVariable("id") Long id) {
        Componentes componentes = componentesService.getComponentesById(id);
        return new ResponseEntity<>(componentes, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Componentes> createComponentes(@RequestBody Componentes componentes) {
        Componentes createdComponentes = componentesService.createComponentes(componentes);
        return new ResponseEntity<>(createdComponentes, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Componentes> updateComponentes(
            @PathVariable("id") Long id, @RequestBody Componentes componentes) {
        Componentes updatedComponentes = componentesService.updateComponentes(id, componentes);
        return new ResponseEntity<>(updatedComponentes, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteComponentes(@PathVariable("id") Long id) {
        componentesService.deleteComponentes(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}