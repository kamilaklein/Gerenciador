package wick.manager2.wickmanager2.model;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Transacao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime dataHora;

    private String tipoTransacao;

    private String projeto; //associar 

    private String laboratorioOrigem;//associar 

    private String laboratorioDestino; //associar 

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public String getTipoTransacao() {
        return tipoTransacao;
    }

    public void setTipoTransacao(String tipoTransacao) {
        this.tipoTransacao = tipoTransacao;
    }

    public String getProjeto() {
        return projeto;
    }

    public void setProjeto(String projeto) {
        this.projeto = projeto;
    }

    public String getLaboratorioOrigem() {
        return laboratorioOrigem;
    }

    public void setLaboratorioOrigem(String laboratorioOrigem) {
        this.laboratorioOrigem = laboratorioOrigem;
    }

    public String getLaboratorioDestino() {
        return laboratorioDestino;
    }

    public void setLaboratorioDestino(String laboratorioDestino) {
        this.laboratorioDestino = laboratorioDestino;
    }

}