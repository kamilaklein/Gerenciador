package wick.manager2.wickmanager2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import wick.manager2.wickmanager2.model.AtividadeLab;
import wick.manager2.wickmanager2.repositories.AtividadeLabRepository;

import java.util.List;

@Service
public class AtividadeLabService {

    private final AtividadeLabRepository atividadeLabRepository;

    @Autowired
    public AtividadeLabService(AtividadeLabRepository atividadeLabRepository) {
        this.atividadeLabRepository = atividadeLabRepository;
    }

    public List<AtividadeLab> listarAtividadesLab() {
        return atividadeLabRepository.findAll();
    }

    public AtividadeLab buscarAtividadeLabPorId(Long id) {
        return atividadeLabRepository.findById(id).orElse(null);
    }

    public AtividadeLab salvarAtividadeLab(AtividadeLab atividadeLab) {
        return atividadeLabRepository.save(atividadeLab);
    }

    public void deletarAtividadeLab(Long id) {
        atividadeLabRepository.deleteById(id);
    }
    
    // Outros métodos de serviço, se necessário

}