package wick.manager2.wickmanager2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import wick.manager2.wickmanager2.model.Laboratorio;
import wick.manager2.wickmanager2.repositories.LaboratorioRepository;

import java.util.List;

@Service
public class LaboratorioService {
    private final LaboratorioRepository laboratorioRepository;

    @Autowired
    public LaboratorioService(LaboratorioRepository laboratorioRepository) {
        this.laboratorioRepository = laboratorioRepository;
    }

    public List<Laboratorio> getAllLaboratorios() {
        return laboratorioRepository.findAll();
    }

    public Laboratorio getLaboratorioById(Long id) {
        return laboratorioRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Laboratorio"));
    }

    public Laboratorio createLaboratorio(Laboratorio laboratorio) {
        return laboratorioRepository.save(laboratorio);
    }

    public Laboratorio updateLaboratorio(Long id, Laboratorio laboratorioDetails) {
        Laboratorio laboratorio = laboratorioRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Laboratorio"));

        laboratorio.setNome(laboratorioDetails.getNome());
        laboratorio.setEndereco(laboratorioDetails.getEndereco());
        laboratorio.setTelefone(laboratorioDetails.getTelefone());

        return laboratorioRepository.save(laboratorio);
    }

    public void deleteLaboratorio(Long id) {
        Laboratorio laboratorio = laboratorioRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Laboratorio"));

        laboratorioRepository.delete(laboratorio);
    }
}